package Jan30;

public class Animal {
}
