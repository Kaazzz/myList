package Jan30;

public class ArrayList extends List {
    void add(int elem) {

    }
}
