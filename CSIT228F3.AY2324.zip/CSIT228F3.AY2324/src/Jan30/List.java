package Jan30;

public abstract class List {
    abstract void add(int elem);
}
