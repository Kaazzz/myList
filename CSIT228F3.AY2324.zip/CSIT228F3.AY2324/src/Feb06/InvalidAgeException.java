package Feb06;

public class InvalidAgeException extends RuntimeException {
}
