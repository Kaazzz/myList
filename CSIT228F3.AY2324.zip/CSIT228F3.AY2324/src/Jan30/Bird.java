package Jan30;

public class Bird implements Flight{
    public void fly() {
        System.out.println("Flapping wings...");
    }
}
