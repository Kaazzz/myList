package Lists;

public class Cat {
    String name;

    public Cat(String name) {
        this.name = name;
    }
    public String toString(){
        return name;
    }

}
