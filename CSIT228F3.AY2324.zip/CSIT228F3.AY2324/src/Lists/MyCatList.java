package Lists;

public class MyCatList {
    private Cat[] array;
    private int size;
    private int capacity;

    public MyCatList() {
        capacity = 5;
        size = 0;
        array = new Cat[capacity];
    }

    public void add(Cat cat) throws ArrayFullException {
        try {
            array[size] = cat;
            size++;
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new ArrayFullException(cat.name);
        }
    }

    public void addAt(int pos, Cat cat) throws ArrayFullException {
        if (pos > size + 1 || pos <= 0) {
            throw new InvalidPositionException(size+1);
        }
        try {
            for (int i = size; i >= pos; i--) {
                array[i] = array[i - 1];
            }
            array[pos-1] =cat;
            size++;
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new ArrayFullException(cat.name);
        }
    }

    public boolean remove(String name) {
        for (int i=0; i < size; i++) {
            if (name.equals(array[i].name)) {
                for (int j = i; j < size-1; j++) {
                    array[j] = array[j+1];
                }
                size--;
                return true;
            }
        }
        return false;
    }

    public Cat removeAt(int pos) {
        if (pos > size || pos <= 0) {
            throw new InvalidPositionException(size);
        }
        Cat ans = array[pos-1];
        for (int i = pos-1; i < size-1; i++) {
            array[i] = array[i+1];
        }
        size--;
        return ans;
    }

    public boolean contains(String name) {
        for(Cat c : array) {
            if (c != null && name.equals(c.name)) {
                return true;
            }
        }
        return false;
    }

    public Cat get(int pos) {
        if (pos > size || pos <= 0) {
            throw new InvalidPositionException(size);
        }
        return array[pos-1];
    }

    public Cat set(int pos, Cat cat) {
        if (pos > size || pos <= 0) {
            throw new InvalidPositionException(size);
        }
        Cat orig = array[pos-1];
        array[pos-1] = cat;
        return orig;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}