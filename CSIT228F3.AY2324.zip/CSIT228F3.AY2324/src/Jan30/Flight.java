package Jan30;

public interface Flight {
    void fly();
}
