package Jan30;

public class Woman extends Human{
    @Override
    public void shave() {
        System.out.println("Shaving my legs");
    }
}
